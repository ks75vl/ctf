<div class="container">    
    <div style="margin-top:50px;" class="mainbox col-md-8 col-md-offset-2 col-sm-8 col-sm-offset-2">                    
        <div class="panel panel-info" >
            <div class="panel-heading">
                <div class="panel-title text-center">Page Not Found!</div>
            </div>                  
        </div>  
    </div>
</div>