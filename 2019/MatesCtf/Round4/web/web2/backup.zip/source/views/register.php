<div class="container">    
    <div id="loginbox" class="mainbox col-sm-12">                    
        <div class="panel panel-info" >
            <div class="panel-heading">
                <div class="panel-title">Register</div>
            </div>     

            <div style="padding-top:30px" class="panel-body" >

                <div style="display:none" id="login-alert" class="alert alert-danger col-sm-8"></div>

                <form class="form-horizontal" role="form" method="POST" action="">
                <div>
                <?php
                    if(isset($data['error'])){
                ?>
                    <div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button><strong><?=$data['error'];?></strong></div>
                <?php } ?>

                <?php
                    if(isset($data['success'])){
                ?>
                    <div class="alert alert-success"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button><strong><?=$data['success'];?></strong></div>
                <?php } ?>
                </div>
                    <div style="margin-bottom: 25px" class="input-group">
                        <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                        <input id="username" type="text" class="form-control" name="username" value="" placeholder="username">                                        
                    </div>

                    <div style="margin-bottom: 25px" class="input-group">
                        <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
                        <input id="password" type="password" class="form-control" name="password" placeholder="password">
                    </div>

                    <div style="margin-bottom: 25px" class="input-group">
                        <span class="input-group-addon">
                            <label>Captcha</label> 
                        </span>
                        <img src="index.php?page=captcha">
                        <input id="captcha" type="text" style="margin-right: 2px" class="form-control" name="captcha">
                    </div>

                    <div style="margin-top:10px" class="form-group">
                        <!-- Button -->

                        <div class="col-sm-12 controls">
                            <input type="submit" value="Sign Up" class="btn btn-success">
                        </div>
                    </div>


                    <div class="form-group">
                        <div class="col-md-12 control">
                            <div style="border-top: 1px solid#888; padding-top:15px; font-size:85%" >
                                <a href="./index.php?page=login" >
                                    Login Here
                                </a>
                            </div>
                        </div>
                    </div>    
                </form>     
            </div>                     
        </div>  
    </div>