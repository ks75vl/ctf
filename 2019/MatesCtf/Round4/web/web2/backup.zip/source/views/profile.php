<div class="container">
	<div class="row">
       <div class="mainbox col-sm-12">
		<div class="panel panel-default">
		  <div class="panel-heading">  <h4>User Profile</h4></div>
		   <div class="panel-body">
		    <div class="box box-info">
	            <div class="box-body">
	            <div class="col-sm-12 text-center">
	            	<h4 style="color:#00b1b1;"><?=$_SESSION['user_login']?></h4>
	            </div>
	            <div class="clearfix"></div>
	            <hr style="margin:5px 0 5px 0;">
		<div class="col-sm-5 col-xs-6 tital " >Name:</div><div class="col-sm-7 col-xs-6 "><?=$_SESSION['user_login']?></div>
		     <div class="clearfix"></div>
		<div class="bot-border"></div>

		<div class="col-sm-5 col-xs-6 tital " >Date Of Joining:</div><div class="col-sm-7">No</div>

		  <div class="clearfix"></div>
		<div class="bot-border"></div>

		<div class="col-sm-5 col-xs-6 tital " >Date Of Birth:</div><div class="col-sm-7">No</div>

		  <div class="clearfix"></div>
		<div class="bot-border"></div>

		<div class="col-sm-5 col-xs-6 tital " >Place Of Birth:</div><div class="col-sm-7">No</div>

		 <div class="clearfix"></div>
		<div class="bot-border"></div>

		<div class="col-sm-5 col-xs-6 tital " >Nationality:</div><div class="col-sm-7">VN</div>

		 <div class="clearfix"></div>
		<div class="bot-border"></div>
          </div>
        </div>
    </div> 
    </div>
</div>   
   </div>
</div>


