<?php
/**
* 
*/
namespace App\Controller;
use App\Controller;
use App\Model\User;
class RegisterController extends Controller
{
    public function execute(){
        $data = array();
        if($_SERVER['REQUEST_METHOD'] == 'POST'){
            if(isset($_POST['captcha']) && $_POST['captcha'] === $_SESSION['captcha_code']){
                $username = $_POST['username'];
                $password = $_POST['password'];
                $user = User::getUserByName($username);
                if(isset($user)){
                    $data['error'] = 'username exists';
                }else{
                    User::save(new User($username, $password));
                    $data['success'] = 'register success';
                }
            }else{
                $data['error'] = "captcha invalid";
            }
        }
        $this->render_template("register.php", $data);
    }
}
?>