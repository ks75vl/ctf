<?php
    /**
    * 
    */
    namespace App\Controller;
	use App\Controller;

    class LogoutController extends Controller
    {
    	public function execute(){
    		unset($_SESSION['user_login']);
            unset($_COOKIE['user_login']);
            setcookie("user_login", "", time() - 3600);
    		header('location: index.php?page=login');
    	}
    }
?>