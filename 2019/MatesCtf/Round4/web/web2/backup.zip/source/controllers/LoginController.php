<?php
/**
* 
*/
namespace App\Controller;
use App\Controller;
use App\Model\User;
use Util\OpenCipher;

class LoginController extends Controller
{
    public function execute(){
        $data = array();
        if($_SERVER['REQUEST_METHOD'] == 'POST'){
            if(isset($_POST['captcha']) && $_POST['captcha'] === $_SESSION['captcha_code']){
                $username = $_POST['username'];
                $password = $_POST['password'];
                $user = User::auth($username, $password);
                if(isset($user)){
                    $_SESSION['user_login'] = $user;
                    $user_enc = OpenCipher::encript(serialize($user));
                    setcookie('user_login', $user_enc, time() + 86400);
                    header('location: index.php');
                    die();
                }else{
                    $data['error'] = 'username or password invalid';
                }
            }else{
                $data['error'] = "captcha invalid";
            }
        }
        $this->render_template("login.php", $data);
    }
}
?>