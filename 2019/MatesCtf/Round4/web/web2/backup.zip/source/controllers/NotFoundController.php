<?php
/**
* 
*/
namespace App\Controller;

use App\Controller;
class NotFoundController extends Controller
{
	public function execute(){
		$this->render_template("404.php", null);
	}
}
?>