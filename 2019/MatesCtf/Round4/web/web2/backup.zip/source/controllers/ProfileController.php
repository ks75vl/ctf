<?php
/**
* 
*/
namespace App\Controller;
use App\Controller;
use App\Model\User;

class ProfileController extends Controller
{
    public function execute(){
        if(isset($_SESSION['user_login'])){
            $this->render_template("profile.php", null);
        }else{
        	header('location: index.php?page=login');
        	die();
        }
    }
}
?>