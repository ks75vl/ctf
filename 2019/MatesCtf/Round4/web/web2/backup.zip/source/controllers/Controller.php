<?php
/**
* 
*/
namespace App;
use Util\OpenCipher;
abstract class Controller
{
	abstract public function execute();

	public static function getApplication(){
		global $controllers;
		$page = "login";
		if(isset($_SESSION['user_login'])){
			$page = "home";
		}else if(isset($_COOKIE['user_login'])){
        	$raw_data = OpenCipher::decript($_COOKIE['user_login']);
        	$raw_data = str_replace(chr(0), '', $raw_data);
        	$user = @unserialize($raw_data);
        	if($user !== false){
        		$_SESSION['user_login'] = $user;
        		$page = "home";
        	}
		}
		if(isset($_GET['page'])){
			$page = $_GET['page'];
			if(!array_key_exists($page, $controllers)){
				$page = "404";
			}
		}
		
		$controller = $controllers[$page];
		$className = $controller['class_name'];
		$classPath = $controller['path'];
		require_once $classPath;
		$className = "App\Controller\\$className";
		return new $className();
	}

	public function render_template($view, $data){
		$view = PATH_VIEW."/".$view;
		$_SESSION['view'] = $view;
		$_SESSION['data'] = $data;
		require_once PATH_VIEW."/layouts/app.php";
	}
}
?>