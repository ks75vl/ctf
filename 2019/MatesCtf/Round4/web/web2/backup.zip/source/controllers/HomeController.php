<?php
/**
* 
*/
namespace App\Controller;
use App\Controller;

class HomeController extends Controller
{
    public function execute(){
        $data = array();
        $this->render_template("home.php", $data);
    }
}
?>