<?php
/**
* 
*/
namespace App\Controller;
use App\Controller;
use App\Util\Captcha;
class CaptchaController extends Controller
{
	public function execute(){
		$code = Captcha::getCaptcha();
		$_SESSION['captcha_code'] = $code;
	}
}
?>