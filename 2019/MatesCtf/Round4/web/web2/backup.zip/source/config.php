<?php

	define('PATH_ROOT', __DIR__);
	define('PATH_CONTROLLER', PATH_ROOT."/controllers");
	define('PATH_VIEW', PATH_ROOT."/views");
	define('PATH_MODEL', PATH_ROOT."/models");

	$databases = array(
		'mysql' => array(
			'host' => 'localhost',
			'port' => '',
			'user' => 'user', 
			'password' => 'password',
			'database' => 'mates_db1'), 
	);

	$utils = array(
		"utils/Captcha.php",
		"utils/OpenCipher.php",
		"utils/log/Log.php",
		"utils/log/ErrorLog.php",
		"utils/log/AccessLog.php",
		"utils/database/Database.php",
		"utils/database/MysqlDatabase.php",
	);

	$models = array(
		'models/User.php');

	$controllers = array(
		'404' => array(
			'path' => PATH_CONTROLLER.'/NotFoundController.php', 
			'class_name' => 'NotFoundController'),
		'captcha' => array(
			'path' => PATH_CONTROLLER.'/CaptchaController.php',
			'class_name' => 'CaptchaController'),
		'login' => array(
			'path' => PATH_CONTROLLER.'/LoginController.php',
			'class_name' => 'LoginController'),
		'register' => array(
			'path' => PATH_CONTROLLER.'/RegisterController.php',
			'class_name' => 'RegisterController'),
		'logout' => array(
			'path' => PATH_CONTROLLER.'/LogoutController.php',
			'class_name' => 'LogoutController'),
		'home' => array(
			'path' => PATH_CONTROLLER.'/HomeController.php',
			'class_name' => 'HomeController'),
		'profile' => array(
			'path' => PATH_CONTROLLER.'/ProfileController.php',
			'class_name' => 'ProfileController'),
	);

//load config//
	
	//load classes
	foreach ($utils as $util) {
		require_once $util;
	}
	//load models
	foreach ($models as $model) {
		require_once $model;
	}
	//load controller
	require_once PATH_CONTROLLER.'/Controller.php';
?>