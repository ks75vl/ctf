<?php
	require_once 'config.php';
	use App\Controller;
	session_start();
	$app = Controller::getApplication();
	$app->execute();
?>