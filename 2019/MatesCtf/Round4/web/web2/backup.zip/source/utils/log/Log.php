<?php
/**
* 
*/
namespace Util;

abstract class Log {
	protected $fileName;

    abstract public function save($message);

    public function clear(){
    	file_put_contents($this->fileName, "");
    }

    public function setFileName($fileName){
		$this->fileName = $fileName;
	}

	public function getFileName(){
		return $this->fileName;
	}
    public function __toString(){
		$content = "";
		if(file_exists($this->fileName)){
			$content = file_get_contents($this->fileName);
		}
		return $content;
	}
}
?>