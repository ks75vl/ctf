<?php
/**
* 
*/
namespace App\Util\Database;

use App\Util\Database\Database;
use \PDO;
class MysqlDatabase extends Database
{
	
	private static $instance = null;

	public function __construct()
	{
		parent::__construct();
		global $databases;
		$options = $databases['mysql'];
		$host = $options['host'];
		$dbname = $options['database'];
		$this->connector = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $options['user'], $options['password']);
	}

	public static function getInstance(){
		if(self::$instance == null){
			self::$instance = new self();
		}
		return self::$instance;
	}

	public function fetchOne(){
		$num_args = func_num_args();
		$args = func_get_args();
		$query = $this->handlerQuery($num_args, $args);
		if($row = $query->fetch()) {
		    return $row;
		}
		return null;
	}

	public function fetchAll(){
		$num_args = func_num_args();
		$args = func_get_args();
		$query = $this->handlerQuery($num_args, $args);
		$result = array();
		while($row = $query->fetch()) {
		    array_push($result, $row);
		}
		return $result;
	}

	public function query(){
		$num_args = func_num_args();
		$args = func_get_args();
		$query = $this->handlerQuery($num_args, $args);
		return $query;
	}

	private function handlerQuery($num_args, $args){
		if($num_args < 1){
			throw new InvalidArgumentException("Invalid argument");
		}
		
		$data = array();
		$query = $this->connector->prepare($args[0]);
		$res = null;
		if($num_args == 1){
			$res = $query->execute();
		}else{
			if(is_array($args[1])){
				$data = $args[1];
			}else{
				for($i=1; $i<$num_args; $i++){
					array_push($data, $args[$i]);
				}
			}
			$res = $query->execute($data);
		}
		if($res == null){
			return null;
		}
		return $query;
	}
}
?>