<?php
/**
* 
*/
namespace Util;

class ErrorLog extends Log
{
	public function __construct(){
		$this->fileName = "logs/error.log";
	}
	public function save($message){
		$time = date('d/m/Y H:i:s', time());
		file_put_contents($this->fileName, $time." [error] ".$message."\n", FILE_APPEND);
	}
}
?>