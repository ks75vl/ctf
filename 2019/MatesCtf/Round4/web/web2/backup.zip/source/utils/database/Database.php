<?php
/**
* 
*/
namespace App\Util\Database;

abstract class Database
{
	protected $connector;
	function __construct(){
	}

	abstract public function fetchOne();
	abstract public function fetchAll();
	abstract public function query();
}
?>