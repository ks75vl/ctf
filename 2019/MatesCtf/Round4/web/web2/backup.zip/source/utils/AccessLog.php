<?php
/**
* 
*/
namespace Util;

class AccessLog extends Log
{
	public function __construct(){
		$this->fileName = "logs/access.log";
	}

	public function save($message){
		$time = date('d/m/Y H:i:s', time());
		file_put_contents($this->fileName, $time." [access] ".$message."\n", FILE_APPEND);
	}
}
?>