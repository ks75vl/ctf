<?php
/**
* 
*/
namespace App\Model;

use App\Util\Database\MysqlDatabase;
class User {	
	public $username;
	public $password;

	function __construct($username, $password){
		$this->username = $username;
		$this->password = $password;
	}

	public static function auth($username, $password){
		$db = MysqlDatabase::getInstance();
		$user = $db->fetchOne("select * from users where username=? and password=?", $username, $password);
		if(!isset($user)){
			return null;
		}
		return new self($user['username'], $user['password']);
	}

	public static function getUserByName($username){
		$db = MysqlDatabase::getInstance();
		$user = $db->fetchOne("select * from users where username=?", $username);
		if(!isset($user)){
			return null;
		}
		return new self($user['username'], $user['password']);
	}

	public static function save(User $user){
		$db = MysqlDatabase::getInstance();
		$userTmp = self::getUserByName($user->getUsername());
		$sql = "insert into users(username, password) values(?, ?)";
		$data = array($user->getUsername(), $user->getPassword());
		if($userTmp !== null){
			$sql = "update users set password = ? where id = ?";
			$data = array($user->getPassword(), $userTmp['id']);
		}
		$db->query($sql, $data);
	}

	public function setUsername($username){
		$this->username = $username;
	}
	public function getUsername(){
		return $this->username;
	}

	public function setPassword($password){
		$this->password = $password;
	}
	public function getPassword(){
		return $this->password;
	}

	public function __toString(){
		try{
			return (string) $this->username;
		} catch (Exception $exception) {
            return '';
        }
	}
}
?>